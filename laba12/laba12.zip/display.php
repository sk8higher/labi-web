<?php
  $name = $_POST["firstname"];
  $surname = $_POST["lastname"];
  echo "Ваше имя: <b>".$name." ".$surname."</b>";
?>
