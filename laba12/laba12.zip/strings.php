<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Строки</title>
</head>
<body>
<?php
  $gm = "Доброе утро";
  $dami = "дамы";
  $gospoda = "и господа";

  echo "Значения переменных: ".$gm.", ".$dami.", ".$gospoda;
  echo nl2br ("\n");
  echo "Сформированная строка: ".$gm." ".$dami." ".$gospoda;
?>
</body>
</html>
