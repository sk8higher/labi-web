<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Операторы</title>
</head>
<body>
<?php
  $frst = 3;
  $scnd = 5;
  $thrd = 8;

  echo "Переменная frst равна ".$frst;
  echo nl2br ("\n");
  echo "Переменная scnd равна ".$scnd;
  echo nl2br ("\n");
  echo "Переменная thrd равна ".$thrd;
  echo nl2br ("\n");

  $sum = $frst + $scnd + $thrd;
  echo "Сумма: ".$sum;
  echo nl2br ("\n");

  $result = 2 + 6 + 2 / 5 - 1;
  echo "Результат примера: ".$result;
?>

</body>
</html>
