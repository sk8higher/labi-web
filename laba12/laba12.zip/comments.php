<?php
  // Симкова Нелли

  /*
   * Дата:
   * 22.11.2023
   */
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Комментарии</title>
</head>
<body>
<?php
  echo "Привет мир!"
?>
</body>
</html>
